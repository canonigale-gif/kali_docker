#!/bin/bash
set -uo pipefail

DIR="${1:-.}"
LOGFILE="fileio_uploads_$(date +%Y%m%d_%H%M%S).log"

# --- Upload helpers ---

upload_fileio() {
    # file.io - anonymous, one-time download link
    curl -sS --connect-timeout 15 -F "file=@$1" https://file.io 2>/dev/null | \
        grep -o '"link":"[^"]*"' | cut -d'"' -f4
}

upload_0x0() {
    curl -sS --connect-timeout 15 -F "file=@$1" https://0x0.st 2>/dev/null
}

upload_transfer() {
    curl -sS --connect-timeout 15 --upload-file "$1" https://transfer.sh 2>/dev/null
}

upload_catbox() {
    curl -sS --connect-timeout 15 -F "reqtype=fileupload" -F "fileToUpload=@$1" \
        https://litterbox.catbox.moe/resources/internals/api.php 2>/dev/null
}

# Try services until one works
upload_file() {
    local file="$1" url=""

    url=$(upload_fileio "$file")
    [[ "$url" == http* ]] && { echo "$url"; return 0; }

    url=$(upload_0x0 "$file")
    [[ "$url" == http* ]] && { echo "$url"; return 0; }

    url=$(upload_transfer "$file")
    [[ "$url" == http* ]] && { echo "$url"; return 0; }

    url=$(upload_catbox "$file")
    [[ "$url" == http* ]] && { echo "$url"; return 0; }

    return 1
}

# --- Main ---

if ! command -v curl &>/dev/null; then
    echo "Error: curl is required." >&2
    exit 1
fi

mapfile -t files < <(find "$DIR" -type f \( \
    -iname "*.sh" \
    -o -iname "Dockerfile" \
    -o -iname "Dockerfile.*" \
\) | sort)

total=${#files[@]}
if [[ $total -eq 0 ]]; then
    echo "No .sh or Dockerfile files found in '$DIR'."
    exit 0
fi

echo "Found $total file(s). Uploading to file.io & fallbacks..." | tee -a "$LOGFILE"
echo "" | tee -a "$LOGFILE"

for f in "${files[@]}"; do
    name=$(basename "$f")
    printf "%-40s " "$name" | tee -a "$LOGFILE"
    
    if url=$(upload_file "$f"); then
        echo "$url" | tee -a "$LOGFILE"
    else
        echo "FAILED" | tee -a "$LOGFILE"
    fi
    
    sleep 1
done

echo "" | tee -a "$LOGFILE"
echo "Done. Log saved to: $LOGFILE" | tee -a "$LOGFILE"
