#!/bin/bash
set -euo pipefail

CONTAINER_NAME="kali-infra"
IMAGE_NAME="kali:snapshot"
TARGET_DIR="$HOME/kali_home"
SAVE_PATH="$TARGET_DIR/gcp-kali-latest.tar.gz"
TMP_SAVE_PATH="$TARGET_DIR/gcp-kali-latest.tmp.tar.gz"

cleanup_on_failure() {
    local exit_code=$?
    if [ $exit_code -ne 0 ]; then
        echo -e "\n\e[31m[-] An error occurred during execution (Exit Code: $exit_code).\e[0m"
        if [ -f "$TMP_SAVE_PATH" ]; then
            echo "[*] Cleaning up partial or corrupted temporary files..."
            rm -f "$TMP_SAVE_PATH"
        fi
    fi
    exit $exit_code
}
trap cleanup_on_failure EXIT

echo -e "\e[34m[*] Verifying container status...\e[0m"
if ! docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    echo -e "\e[31m[-] Error: Container '${CONTAINER_NAME}' does not exist or is inaccessible.\e[0m"
    exit 1
fi

echo -e "\e[34m[*] Committing live container modifications to local image metadata...\e[0m"
docker commit "$CONTAINER_NAME" "$IMAGE_NAME"

echo -e "\e[34m[*] Checking persistent storage capacities...\e[0m"
mkdir -p "$TARGET_DIR"

VIRTUAL_SIZE_BYTES=$(docker inspect --format='{{.Size}}' "$IMAGE_NAME" 2>/dev/null || echo 0)
ESTIMATED_COMPRESSED_BYTES=$((VIRTUAL_SIZE_BYTES * 35 / 100))
AVAILABLE_HOME_BYTES=$(df -P "$HOME" | tail -1 | awk '{print $4 * 1024}')

echo " - Container Virtual Payload: $((VIRTUAL_SIZE_BYTES / 1024 / 1024)) MB"
echo " - Predicted Archive Requirement: $((ESTIMATED_COMPRESSED_BYTES / 1024 / 1024)) MB"
echo " - Free Quota Available: $((AVAILABLE_HOME_BYTES / 1024 / 1024)) MB"

COMPRESSION_LEVEL="-6"

if [ "$AVAILABLE_HOME_BYTES" -le "$ESTIMATED_COMPRESSED_BYTES" ]; then
    echo -e "\e[33m[!] Warning: Low disk space detected on persistent partition.\e[0m"
    CRITICAL_BUFFER=$((100 * 1024 * 1024))
    
    if [ "$AVAILABLE_HOME_BYTES" -le "$CRITICAL_BUFFER" ]; then
        echo -e "\e[31m[-] Critical Storage Deficit: Aborting operation to prevent host lockup.\e[0m"
        exit 1
    else
        echo -e "\e[33m[*] Attempting mitigation: Engaging Maximum Deep Compression Suite (-9)...\e[0m"
        COMPRESSION_LEVEL="-9"
    fi
fi

echo -e "\e[34m[*] Exporting filesystem layer to temporary pipe matrix...\e[0m"
docker save "$IMAGE_NAME" | gzip "$COMPRESSION_LEVEL" > "$TMP_SAVE_PATH"

echo -e "\e[34m[*] Testing archive data integrity before disk commit...\e[0m"
if gzip -t "$TMP_SAVE_PATH"; then
    echo -e "\e[32m[+] Integrity passed. Atomically updating production backup asset...\e[0m"
    mv -f "$TMP_SAVE_PATH" "$SAVE_PATH"
else
    echo -e "\e[31m[-] Error: Generated archive failed structural parity test.\e[0m"
    rm -f "$TMP_SAVE_PATH"
    exit 1
fi

echo -e "\e[32m[+] Cycle complete! Image compiled successfully.\e[0m"
echo "--------------------------------------------------------"
echo " Storage Free Space Remaining: $(df -h "$HOME" | tail -n 1 | awk '{print $4}')"
echo "--------------------------------------------------------"
