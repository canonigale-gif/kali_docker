#!/bin/bash
set -euo pipefail

CONTAINER_NAME="kali-infra"
IMAGE_NAME="kali:snapshot"
SAVE_PATH="$HOME/kali_home/gcp-kali-latest.tar.gz"

echo -e "\e[34m[*] Auditing archive state indicators...\e[0m"
if [ ! -f "$SAVE_PATH" ]; then
    echo -e "\e[31m[-] Deployment Error: Target image payload file missing at $SAVE_PATH\e[0m"
    exit 1
fi

if ! gzip -t "$SAVE_PATH" 2>/dev/null; then
    echo -e "\e[31m[-] Structural Error: Compressed archive is corrupted or cut off.\e[0m"
    echo "Recommendation: Rebuild image file utilizing the Dockerfile asset directly."
    exit 1
fi

echo -e "\e[34m[*] Evaluating host Docker runtime capacity metrics...\e[0m"
EPHEMERAL_FREE_KB=$(df -P / | tail -1 | awk '{print $4}')

if [ "$EPHEMERAL_FREE_KB" -lt 5242880 ]; then
    echo -e "\e[33m[!] Host cache allocation warning. Dropping legacy build artifacts...\e[0m"
    docker system prune -f --volumes > /dev/null
fi

if docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    echo -e "\e[33m[*] Resetting stale execution namespace lock for '${CONTAINER_NAME}'...\e[0m"
    docker rm -f "$CONTAINER_NAME" > /dev/null
fi

echo -e "\e[34m[*] Loading verified binary snapshot streams to Docker platform engine...\e[0m"
docker load -i "$SAVE_PATH"

echo -e "\e[34m[*] Mounting initialized systemd virtualization engine into host namespace...\e[0m"
docker run -d \
  --name "$CONTAINER_NAME" \
  --privileged \
  --cgroupns=host \
  -v "$HOME/kali_home:/home/ctx/kali_home" \
  "$IMAGE_NAME"

echo -e "\e[34m[*] Enforcing target permission sync for non-root context identity...\e[0m"
docker exec "$CONTAINER_NAME" chown -R ctx:ctx /home/ctx/kali_home

echo -e "\e[32m[+] Infrastructure recovery sequence verified and established!\e[0m"
echo "=========================================================="
echo " To execute your custom multiplexed shell terminal, run:"
echo -e " \e[1;36mdocker exec -it --user ctx ${CONTAINER_NAME} /bin/bash\e[0m"
echo "=========================================================="
docker exec -it -u ctx kali-infra  /bin/bash
